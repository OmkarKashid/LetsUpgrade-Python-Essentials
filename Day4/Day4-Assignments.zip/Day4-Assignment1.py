str="what we think we become; we are Python programmer"
substr=input("Enter a substring to search ")
count=len(substr)
n=len(str)
ispresent=False
for i in range(n):
    if str[i]==substr[0] :
        if str[i:i+count]== substr :
            print(i)
            ispresent=True
if ispresent==False:
    print("Not Present")

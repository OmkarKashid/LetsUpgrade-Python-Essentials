str1="abcd"
str2="ABCD"
str3="abCD"
str4="!@#abcd"
str5="!@#ABCD"
str6="!23aBC5%"

print("For string 1",str1,"using islower()- ",str1.islower())
print("For string 1",str1,"using isupper()- ",str1.isupper())
print("For string 2",str2,"using islower()- ",str2.islower())
print("For string 2",str2,"using isupper()- ",str2.isupper())
print("For string 3",str3,"using islower()- ",str3.islower())
print("For string 3",str3,"using isupper()- ",str3.isupper())
print("For string 4",str4,"using islower()- ",str4.islower())
print("For string 5",str5,"using isupper()- ",str5.isupper())
print("For string 6",str6,"using islower()- ",str6.islower())
print("For string 6",str6,"using isupper()- ",str6.isupper())
list1=[0,1,2,10,4,1,0,56,2,0,1,3,0,56,0,4]
max1=max(list1)
def fun1(x):
    if x!=0:
        return x
    else:
        return max1+1
list1.sort(key=fun1)
print(list1)
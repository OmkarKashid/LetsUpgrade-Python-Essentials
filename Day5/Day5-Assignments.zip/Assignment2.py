list1=[10,20,40,60,70,80]
list2=[5,15,25,35,45,60]
a,b=0,0
size_a=len(list1)
size_b=len(list2)
total_size=len(list1)+len(list2)
list3=[]
while a+b<total_size:
    if a==size_a :
        list3.append(list2[b])
        b+=1
    elif b==size_b:
        list3.append(list1[a])
        a+=1
    elif (list1[a])>(list2[b]):
        list3.append(list2[b])
        b+=1
    else:
        list3.append(list1[a])
        a+=1
print(list3)